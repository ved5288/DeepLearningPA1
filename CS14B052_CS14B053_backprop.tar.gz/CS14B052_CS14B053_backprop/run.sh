python  train.py --lr 0.002 --momentum 0.001 --num_hidden 1 --sizes 200 --activation sigmoid --loss ce --pretrain False --val val.csv --opt adam --batch_size 20 --anneal true --save_dir pa1/Q1/size200/ --expt_dir pa1/Q1/size200/ --train train.csv --test test.csv
 
